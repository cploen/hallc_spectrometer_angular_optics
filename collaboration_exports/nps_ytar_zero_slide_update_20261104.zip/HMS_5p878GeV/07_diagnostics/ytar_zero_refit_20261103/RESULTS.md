# Saved-basis Ytar constant comparison

Only Ytar coefficients were refitted. Exact beam terms and saved training/holdout IDs reused.

| Pool | Model | Target | N | Bias | Spread | RMS |
|---|---|---|---:|---:|---:|---:|
| core | old | ytar | 30389 | 0.0333898 | 0.155678 | 0.159219 |
| core | old | ztar | 30389 | 0.128813 | 0.582303 | 0.59638 |
| core | beam | ytar | 30389 | 0.00574123 | 0.134155 | 0.134278 |
| core | beam | ztar | 30389 | 0.0212606 | 0.502616 | 0.503065 |
| core | dropped | ytar | 30389 | 0.00808176 | 0.134155 | 0.134399 |
| core | dropped | ztar | 30389 | 0.0300267 | 0.502591 | 0.503488 |
| core | refit | ytar | 30389 | 0.00597279 | 0.134172 | 0.134305 |
| core | refit | ztar | 30389 | 0.0221031 | 0.502668 | 0.503154 |
| noncore | old | ytar | 9135 | 0.0384695 | 0.177877 | 0.181989 |
| noncore | old | ztar | 9135 | 0.149281 | 0.664821 | 0.681375 |
| noncore | beam | ytar | 9135 | 0.001893 | 0.160287 | 0.160298 |
| noncore | beam | ztar | 9135 | 0.00823876 | 0.60128 | 0.601336 |
| noncore | dropped | ytar | 9135 | 0.00423353 | 0.160287 | 0.160343 |
| noncore | dropped | ztar | 9135 | 0.016996 | 0.601281 | 0.601521 |
| noncore | refit | ytar | 9135 | 0.00212147 | 0.160313 | 0.160327 |
| noncore | refit | ztar | 9135 | 0.00907073 | 0.601366 | 0.601434 |
| core_shoulder | old | ytar | 39524 | 0.0345638 | 0.161095 | 0.164761 |
| core_shoulder | old | ztar | 39524 | 0.133544 | 0.602442 | 0.617066 |
| core_shoulder | beam | ytar | 39524 | 0.00485181 | 0.140636 | 0.14072 |
| core_shoulder | beam | ztar | 39524 | 0.018251 | 0.527092 | 0.527408 |
| core_shoulder | dropped | ytar | 39524 | 0.00719234 | 0.140636 | 0.14082 |
| core_shoulder | dropped | ztar | 39524 | 0.0270149 | 0.527074 | 0.527766 |
| core_shoulder | refit | ytar | 39524 | 0.00508265 | 0.140656 | 0.140748 |
| core_shoulder | refit | ztar | 39524 | 0.019091 | 0.527153 | 0.527498 |
| unsupported | old | ytar | 1112 | 0.035497 | 0.220328 | 0.223169 |
| unsupported | old | ztar | 1112 | 0.15331 | 0.781529 | 0.796424 |
| unsupported | beam | ytar | 1112 | -0.0252924 | 0.186992 | 0.188695 |
| unsupported | beam | ztar | 1112 | -0.0818585 | 0.663385 | 0.668417 |
| unsupported | dropped | ytar | 1112 | -0.0229518 | 0.186992 | 0.188395 |
| unsupported | dropped | ztar | 1112 | -0.0735129 | 0.663409 | 0.66747 |
| unsupported | refit | ytar | 1112 | -0.025299 | 0.186951 | 0.188655 |
| unsupported | refit | ztar | 1112 | -0.0818713 | 0.663245 | 0.668279 |

Units: Ytar and derived Ztar cm; angular metrics mrad. Spread is mean-subtracted standard deviation; RMS includes bias.

Primary comparison: refit versus dropped. Beam retains its fitted constant as a diagnostic reference. Old uses the pinned 2024 offsets.

core_shoulder includes all supported quality-1 events, not only the inner shoulder used in training. Blocked events are excluded from metrics.

Signed residuals are never recentered. PNG distributions use a shared P99 window; TSV/NPZ metrics retain every event. Sparse cells N<10 remain visible.

Holdout has already been used in prior reports; this is a paired comparison, not a new untouched final test. No event selections or replay installations changed.
