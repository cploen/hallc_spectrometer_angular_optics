# Saved-basis Ytar constant comparison

Only Ytar coefficients were refitted. Exact beam terms and saved training/holdout IDs reused.

| Pool | Model | Target | N | Bias | Spread | RMS |
|---|---|---|---:|---:|---:|---:|
| core | old | ytar | 78091 | 0.0118418 | 0.141798 | 0.142291 |
| core | old | ztar | 78091 | 0.0581448 | 0.663635 | 0.666177 |
| core | beam | ytar | 78091 | 0.0113575 | 0.135893 | 0.136366 |
| core | beam | ztar | 78091 | 0.0549447 | 0.637613 | 0.639976 |
| core | dropped | ytar | 78091 | -0.00397671 | 0.135893 | 0.135951 |
| core | dropped | ztar | 78091 | -0.0170287 | 0.637654 | 0.637881 |
| core | refit | ytar | 78091 | 0.0100091 | 0.13587 | 0.136238 |
| core | refit | ztar | 78091 | 0.0487267 | 0.637499 | 0.639359 |
| noncore | old | ytar | 22049 | 0.0138941 | 0.171957 | 0.172517 |
| noncore | old | ztar | 22049 | 0.0667887 | 0.804278 | 0.807046 |
| noncore | beam | ytar | 22049 | 0.00787416 | 0.164479 | 0.164667 |
| noncore | beam | ztar | 22049 | 0.037054 | 0.771868 | 0.772757 |
| noncore | dropped | ytar | 22049 | -0.00746007 | 0.164479 | 0.164648 |
| noncore | dropped | ztar | 22049 | -0.0347073 | 0.772018 | 0.772798 |
| noncore | refit | ytar | 22049 | 0.00660065 | 0.164442 | 0.164574 |
| noncore | refit | ztar | 22049 | 0.0312005 | 0.771667 | 0.772297 |
| core_shoulder | old | ytar | 100140 | 0.0122937 | 0.148966 | 0.149472 |
| core_shoulder | old | ztar | 100140 | 0.060048 | 0.697052 | 0.699633 |
| core_shoulder | beam | ytar | 100140 | 0.0105905 | 0.142687 | 0.143079 |
| core_shoulder | beam | ztar | 100140 | 0.0510055 | 0.66953 | 0.67147 |
| core_shoulder | dropped | ytar | 100140 | -0.00474368 | 0.142687 | 0.142765 |
| core_shoulder | dropped | ztar | 100140 | -0.0209212 | 0.669598 | 0.669924 |
| core_shoulder | refit | ytar | 100140 | 0.00925864 | 0.14266 | 0.14296 |
| core_shoulder | refit | ztar | 100140 | 0.0448677 | 0.669393 | 0.670895 |
| unsupported | old | ytar | 585 | 0.0251386 | 0.236476 | 0.237808 |
| unsupported | old | ztar | 585 | 0.126664 | 0.991185 | 0.999246 |
| unsupported | beam | ytar | 585 | 0.00881631 | 0.193515 | 0.193716 |
| unsupported | beam | ztar | 585 | 0.0333174 | 0.814659 | 0.81534 |
| unsupported | dropped | ytar | 585 | -0.00651792 | 0.193515 | 0.193625 |
| unsupported | dropped | ztar | 585 | -0.0293567 | 0.814891 | 0.81542 |
| unsupported | refit | ytar | 585 | 0.0088492 | 0.193528 | 0.19373 |
| unsupported | refit | ztar | 585 | 0.0332496 | 0.814702 | 0.81538 |

Units: Ytar and derived Ztar cm; angular metrics mrad. Spread is mean-subtracted standard deviation; RMS includes bias.

Primary comparison: refit versus dropped. Beam retains its fitted constant as a diagnostic reference. Old uses the pinned 2024 offsets.

core_shoulder includes all supported quality-1 events, not only the inner shoulder used in training. Blocked events are excluded from metrics.

Signed residuals are never recentered. PNG distributions use a shared P99 window; TSV/NPZ metrics retain every event. Sparse cells N<10 remain visible.

Holdout has already been used in prior reports; this is a paired comparison, not a new untouched final test. No event selections or replay installations changed.
