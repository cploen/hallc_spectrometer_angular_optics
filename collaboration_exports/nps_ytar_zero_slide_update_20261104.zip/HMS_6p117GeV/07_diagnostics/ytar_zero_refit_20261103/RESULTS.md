# Saved-basis Ytar constant comparison

Only Ytar coefficients were refitted. Exact beam terms and saved training/holdout IDs reused.

| Pool | Model | Target | N | Bias | Spread | RMS |
|---|---|---|---:|---:|---:|---:|
| core | old | ytar | 145166 | 0.0376735 | 0.159468 | 0.163858 |
| core | old | ztar | 145166 | 0.20422 | 0.772675 | 0.799207 |
| core | beam | ytar | 145166 | -0.00191655 | 0.133199 | 0.133213 |
| core | beam | ztar | 145166 | -0.00482812 | 0.646693 | 0.646711 |
| core | dropped | ytar | 145166 | 0.00966777 | 0.133199 | 0.13355 |
| core | dropped | ztar | 145166 | 0.0512879 | 0.646751 | 0.648781 |
| core | refit | ytar | 145166 | -0.00104043 | 0.133236 | 0.13324 |
| core | refit | ztar | 145166 | -0.000738368 | 0.646869 | 0.646869 |
| noncore | old | ytar | 39326 | 0.0442363 | 0.186911 | 0.192074 |
| noncore | old | ztar | 39326 | 0.234719 | 0.90286 | 0.932871 |
| noncore | beam | ytar | 39326 | -0.000811612 | 0.17045 | 0.170452 |
| noncore | beam | ztar | 39326 | -0.00199983 | 0.829628 | 0.82963 |
| noncore | dropped | ytar | 39326 | 0.0107727 | 0.17045 | 0.17079 |
| noncore | dropped | ztar | 39326 | 0.0541437 | 0.829524 | 0.831289 |
| noncore | refit | ytar | 39326 | 3.00535e-05 | 0.170502 | 0.170502 |
| noncore | refit | ztar | 39326 | 0.00189974 | 0.829938 | 0.82994 |
| core_shoulder | old | ytar | 184492 | 0.0390724 | 0.165721 | 0.170265 |
| core_shoulder | old | ztar | 184492 | 0.210721 | 0.802296 | 0.829507 |
| core_shoulder | beam | ytar | 184492 | -0.00168102 | 0.141962 | 0.141972 |
| core_shoulder | beam | ztar | 184492 | -0.00422525 | 0.689768 | 0.689781 |
| core_shoulder | dropped | ytar | 184492 | 0.00990329 | 0.141962 | 0.142307 |
| core_shoulder | dropped | ztar | 184492 | 0.0518967 | 0.689785 | 0.691734 |
| core_shoulder | refit | ytar | 184492 | -0.000812244 | 0.142002 | 0.142005 |
| core_shoulder | refit | ztar | 184492 | -0.000176034 | 0.689978 | 0.689978 |
| unsupported | old | ytar | 241 | 0.0350768 | 0.218308 | 0.221108 |
| unsupported | old | ztar | 241 | 0.182203 | 1.03015 | 1.04614 |
| unsupported | beam | ytar | 241 | -0.0312554 | 0.251496 | 0.253431 |
| unsupported | beam | ztar | 241 | -0.195624 | 1.2232 | 1.23874 |
| unsupported | dropped | ytar | 241 | -0.019671 | 0.251496 | 0.252264 |
| unsupported | dropped | ztar | 241 | -0.139933 | 1.22081 | 1.2288 |
| unsupported | refit | ytar | 241 | -0.0313763 | 0.251981 | 0.253927 |
| unsupported | refit | ztar | 241 | -0.196261 | 1.22562 | 1.24124 |

Units: Ytar and derived Ztar cm; angular metrics mrad. Spread is mean-subtracted standard deviation; RMS includes bias.

Primary comparison: refit versus dropped. Beam retains its fitted constant as a diagnostic reference. Old uses the pinned 2024 offsets.

core_shoulder includes all supported quality-1 events, not only the inner shoulder used in training. Blocked events are excluded from metrics.

Signed residuals are never recentered. PNG distributions use a shared P99 window; TSV/NPZ metrics retain every event. Sparse cells N<10 remain visible.

Holdout has already been used in prior reports; this is a paired comparison, not a new untouched final test. No event selections or replay installations changed.
